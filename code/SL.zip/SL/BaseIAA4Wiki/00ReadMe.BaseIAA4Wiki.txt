Dear all

As agreed in BW3, we are distributing the spectra of SSPs younger than the 63Myr limit of MILES.
These may be used by whoever wants to check the influence of young stars in spectral analysis.

The files are in 

The young SSPs are the BR*K and br04*K files. The corresponding ages and metallicities are
listed in the BASE.IAA2012.All file. There are 60 such files, 15 ages x 4 metallicities.

We also send the 350 MILES SSPs we used. These are the same in the IAC site, but resampled
to 1 Angs to be compatible with the younger other ones. All models are for a Salpeter IMF
and Padova 200 models (except for the 2 youngest ages, where we use Geneva models,
presumably better for 1st few Myr).


